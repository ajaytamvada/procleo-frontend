// Mock for static assets in Jest tests
module.exports = 'test-file-stub';
