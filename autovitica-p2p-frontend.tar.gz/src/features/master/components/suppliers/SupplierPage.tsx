// Re-export the VendorPage as SupplierPage for routing compatibility
export { default } from '../vendor/VendorPage';